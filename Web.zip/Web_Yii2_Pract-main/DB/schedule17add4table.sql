﻿--
-- Скрипт сгенерирован Devart dbForge Studio 2020 for MySQL, Версия 9.0.435.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 04.11.2020 18:47:52
-- Версия сервера: 10.3.22
-- Версия клиента: 4.1
--

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

--
-- Установка базы данных по умолчанию
--
USE schedule08;

--
-- Удалить таблицу `migration`
--
DROP TABLE IF EXISTS migration;

--
-- Удалить таблицу `schedule`
--
DROP TABLE IF EXISTS schedule;

--
-- Удалить таблицу `classroom`
--
DROP TABLE IF EXISTS classroom;

--
-- Удалить таблицу `day`
--
DROP TABLE IF EXISTS day;

--
-- Удалить таблицу `lesson_num`
--
DROP TABLE IF EXISTS lesson_num;

--
-- Удалить таблицу `auth_assignment`
--
DROP TABLE IF EXISTS auth_assignment;

--
-- Удалить таблицу `auth_item_child`
--
DROP TABLE IF EXISTS auth_item_child;

--
-- Удалить таблицу `auth_item`
--
DROP TABLE IF EXISTS auth_item;

--
-- Удалить таблицу `auth_rule`
--
DROP TABLE IF EXISTS auth_rule;

--
-- Удалить таблицу `lesson_plan`
--
DROP TABLE IF EXISTS lesson_plan;

--
-- Удалить таблицу `student`
--
DROP TABLE IF EXISTS student;

--
-- Удалить таблицу `gruppa`
--
DROP TABLE IF EXISTS gruppa;

--
-- Удалить таблицу `special`
--
DROP TABLE IF EXISTS special;

--
-- Удалить таблицу `subject`
--
DROP TABLE IF EXISTS subject;

--
-- Удалить таблицу `teacher`
--
DROP TABLE IF EXISTS teacher;

--
-- Удалить таблицу `otdel`
--
DROP TABLE IF EXISTS otdel;

--
-- Удалить таблицу `user`
--
DROP TABLE IF EXISTS user;

--
-- Удалить таблицу `gender`
--
DROP TABLE IF EXISTS gender;

--
-- Установка базы данных по умолчанию
--
USE schedule08;

--
-- Создать таблицу `gender`
--
CREATE TABLE gender (
  gender_id tinyint(4) NOT NULL AUTO_INCREMENT,
  name varchar(10) NOT NULL,
  PRIMARY KEY (gender_id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 3,
AVG_ROW_LENGTH = 8192,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать таблицу `user`
--
CREATE TABLE user (
  user_id bigint(20) NOT NULL AUTO_INCREMENT,
  lastname varchar(50) NOT NULL,
  firstname varchar(55) NOT NULL,
  patronymic varchar(55) DEFAULT NULL,
  login varchar(255) DEFAULT NULL,
  pass varchar(255) DEFAULT NULL,
  token varchar(255) DEFAULT NULL,
  expired_at int(11) DEFAULT NULL,
  gender_id tinyint(4) NOT NULL,
  birthday date DEFAULT NULL,
  active tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (user_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE user
ADD CONSTRAINT FK_user_gender_gender_id FOREIGN KEY (gender_id)
REFERENCES gender (gender_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `otdel`
--
CREATE TABLE otdel (
  otdel_id smallint(6) NOT NULL AUTO_INCREMENT,
  name varchar(50) NOT NULL,
  active tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (otdel_id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 4,
AVG_ROW_LENGTH = 5461,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать таблицу `teacher`
--
CREATE TABLE teacher (
  user_id bigint(20) NOT NULL,
  otdel_id smallint(6) NOT NULL,
  PRIMARY KEY (user_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE teacher
ADD CONSTRAINT FK_teacher_otdel_otdel_id FOREIGN KEY (otdel_id)
REFERENCES otdel (otdel_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать внешний ключ
--
ALTER TABLE teacher
ADD CONSTRAINT FK_teacher_user_user_id FOREIGN KEY (user_id)
REFERENCES user (user_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `subject`
--
CREATE TABLE subject (
  subject_id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(50) NOT NULL,
  otdel_id smallint(6) NOT NULL,
  hours smallint(6) NOT NULL,
  active tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (subject_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE subject
ADD CONSTRAINT FK_subject_otdel_otdel_id FOREIGN KEY (otdel_id)
REFERENCES otdel (otdel_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `special`
--
CREATE TABLE special (
  special_id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(250) NOT NULL,
  otdel_id smallint(6) NOT NULL,
  active tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (special_id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 6,
AVG_ROW_LENGTH = 3276,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE special
ADD CONSTRAINT FK_special_otdel_otdel_id FOREIGN KEY (otdel_id)
REFERENCES otdel (otdel_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `gruppa`
--
CREATE TABLE gruppa (
  gruppa_id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(10) NOT NULL,
  special_id int(11) NOT NULL,
  date_begin date NOT NULL,
  date_end date DEFAULT NULL,
  PRIMARY KEY (gruppa_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE gruppa
ADD CONSTRAINT FK_gruppa_special_special_id FOREIGN KEY (special_id)
REFERENCES special (special_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `student`
--
CREATE TABLE student (
  user_id bigint(20) NOT NULL,
  gruppa_id int(11) NOT NULL,
  num_zach varchar(10) NOT NULL,
  PRIMARY KEY (user_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE student
ADD CONSTRAINT FK_student_gruppa_gruppa_id FOREIGN KEY (gruppa_id)
REFERENCES gruppa (gruppa_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать внешний ключ
--
ALTER TABLE student
ADD CONSTRAINT FK_student_user_user_id FOREIGN KEY (user_id)
REFERENCES user (user_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `lesson_plan`
--
CREATE TABLE lesson_plan (
  lesson_plan_id int(11) NOT NULL AUTO_INCREMENT,
  gruppa_id int(11) NOT NULL,
  subject_id int(11) NOT NULL,
  user_id bigint(20) NOT NULL,
  PRIMARY KEY (lesson_plan_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE lesson_plan
ADD CONSTRAINT FK_lesson_plan_gruppa_gruppa_id FOREIGN KEY (gruppa_id)
REFERENCES gruppa (gruppa_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать внешний ключ
--
ALTER TABLE lesson_plan
ADD CONSTRAINT FK_lesson_plan_subject_subject_id FOREIGN KEY (subject_id)
REFERENCES subject (subject_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать внешний ключ
--
ALTER TABLE lesson_plan
ADD CONSTRAINT FK_lesson_plan_teacher_user_id FOREIGN KEY (user_id)
REFERENCES teacher (user_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `auth_rule`
--
CREATE TABLE auth_rule (
  name varchar(64) NOT NULL,
  data blob DEFAULT NULL,
  created_at int(11) DEFAULT NULL,
  updated_at int(11) DEFAULT NULL,
  PRIMARY KEY (name)
)
ENGINE = INNODB,
CHARACTER SET utf8,
COLLATE utf8_unicode_ci;

--
-- Создать таблицу `auth_item`
--
CREATE TABLE auth_item (
  name varchar(64) NOT NULL,
  type smallint(6) NOT NULL,
  description text DEFAULT NULL,
  rule_name varchar(64) DEFAULT NULL,
  data blob DEFAULT NULL,
  created_at int(11) DEFAULT NULL,
  updated_at int(11) DEFAULT NULL,
  PRIMARY KEY (name)
)
ENGINE = INNODB,
AVG_ROW_LENGTH = 3276,
CHARACTER SET utf8,
COLLATE utf8_unicode_ci;

--
-- Создать индекс `idx-auth_item-type` для объекта типа таблица `auth_item`
--
ALTER TABLE auth_item
ADD INDEX `idx-auth_item-type` (type);

--
-- Создать внешний ключ
--
ALTER TABLE auth_item
ADD CONSTRAINT auth_item_ibfk_1 FOREIGN KEY (rule_name)
REFERENCES auth_rule (name) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Создать таблицу `auth_item_child`
--
CREATE TABLE auth_item_child (
  parent varchar(64) NOT NULL,
  child varchar(64) NOT NULL,
  PRIMARY KEY (parent, child)
)
ENGINE = INNODB,
AVG_ROW_LENGTH = 8192,
CHARACTER SET utf8,
COLLATE utf8_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE auth_item_child
ADD CONSTRAINT auth_item_child_ibfk_1 FOREIGN KEY (parent)
REFERENCES auth_item (name) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Создать внешний ключ
--
ALTER TABLE auth_item_child
ADD CONSTRAINT auth_item_child_ibfk_2 FOREIGN KEY (child)
REFERENCES auth_item (name) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Создать таблицу `auth_assignment`
--
CREATE TABLE auth_assignment (
  item_name varchar(64) NOT NULL,
  user_id varchar(64) NOT NULL,
  created_at int(11) DEFAULT NULL,
  PRIMARY KEY (item_name, user_id)
)
ENGINE = INNODB,
AVG_ROW_LENGTH = 16384,
CHARACTER SET utf8,
COLLATE utf8_unicode_ci;

--
-- Создать индекс `idx-auth_assignment-user_id` для объекта типа таблица `auth_assignment`
--
ALTER TABLE auth_assignment
ADD INDEX `idx-auth_assignment-user_id` (user_id);

--
-- Создать внешний ключ
--
ALTER TABLE auth_assignment
ADD CONSTRAINT auth_assignment_ibfk_1 FOREIGN KEY (item_name)
REFERENCES auth_item (name) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Создать таблицу `lesson_num`
--
CREATE TABLE lesson_num (
  lesson_num_id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(10) NOT NULL,
  time_lesson time NOT NULL,
  PRIMARY KEY (lesson_num_id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 6,
AVG_ROW_LENGTH = 3276,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать таблицу `day`
--
CREATE TABLE day (
  day_id tinyint(4) NOT NULL AUTO_INCREMENT,
  name varchar(50) NOT NULL,
  PRIMARY KEY (day_id)
)
ENGINE = INNODB,
AUTO_INCREMENT = 8,
AVG_ROW_LENGTH = 2340,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать таблицу `classroom`
--
CREATE TABLE classroom (
  classroom_id int(11) NOT NULL AUTO_INCREMENT,
  name varchar(20) NOT NULL,
  active tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (classroom_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать таблицу `schedule`
--
CREATE TABLE schedule (
  schedule_id int(11) NOT NULL AUTO_INCREMENT,
  lesson_plan_id int(11) NOT NULL,
  day_id tinyint(4) NOT NULL,
  lesson_num_id int(11) NOT NULL,
  classroom_id int(11) NOT NULL,
  PRIMARY KEY (schedule_id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

--
-- Создать внешний ключ
--
ALTER TABLE schedule
ADD CONSTRAINT FK_schedule_classroom_classroom_id FOREIGN KEY (classroom_id)
REFERENCES classroom (classroom_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать внешний ключ
--
ALTER TABLE schedule
ADD CONSTRAINT FK_schedule_day_day_id FOREIGN KEY (day_id)
REFERENCES day (day_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать внешний ключ
--
ALTER TABLE schedule
ADD CONSTRAINT FK_schedule_lesson_num_lesson_num_id FOREIGN KEY (lesson_num_id)
REFERENCES lesson_num (lesson_num_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать внешний ключ
--
ALTER TABLE schedule
ADD CONSTRAINT FK_schedule_lesson_plan_lesson_plan_id FOREIGN KEY (lesson_plan_id)
REFERENCES lesson_plan (lesson_plan_id) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Создать таблицу `migration`
--
CREATE TABLE migration (
  version varchar(180) NOT NULL,
  apply_time int(11) DEFAULT NULL,
  PRIMARY KEY (version)
)
ENGINE = INNODB,
AVG_ROW_LENGTH = 3276,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_unicode_ci;

-- 
-- Вывод данных для таблицы gender
--
INSERT INTO gender VALUES
(1, 'Мужской'),
(2, 'Женский');

-- 
-- Вывод данных для таблицы user
--
-- Таблица schedule08.user не содержит данных

-- 
-- Вывод данных для таблицы otdel
--
INSERT INTO otdel VALUES
(1, 'Программирование', 1),
(2, 'Общеобразовательные дисциплины', 1),
(3, 'Строительство', 1);

-- 
-- Вывод данных для таблицы special
--
INSERT INTO special VALUES
(1, 'Информационные системы', 1, 1),
(2, 'Нефтегазвое дело', 2, 1),
(3, 'Строительство и эксплуатация зданий и сооружений', 3, 1),
(4, 'Электроснабжение', 3, 1),
(5, 'Вычислительная техника и программное обеспечение', 1, 1);

-- 
-- Вывод данных для таблицы teacher
--
-- Таблица schedule08.teacher не содержит данных

-- 
-- Вывод данных для таблицы subject
--
-- Таблица schedule08.subject не содержит данных

-- 
-- Вывод данных для таблицы auth_rule
--
-- Таблица schedule08.auth_rule не содержит данных

-- 
-- Вывод данных для таблицы gruppa
--
-- Таблица schedule08.gruppa не содержит данных

-- 
-- Вывод данных для таблицы lesson_plan
--
-- Таблица schedule08.lesson_plan не содержит данных

-- 
-- Вывод данных для таблицы lesson_num
--
INSERT INTO lesson_num VALUES
(1, '1 пара', '08:30:00'),
(2, '2 пара', '10:10:00'),
(3, '3 пара', '12:20:00'),
(4, '4 пара', '14:00:00'),
(5, '5 пара', '15:40:00');

-- 
-- Вывод данных для таблицы day
--
INSERT INTO day VALUES
(1, 'Понедельник'),
(2, 'Вторник'),
(3, 'Среда'),
(4, 'Четверг'),
(5, 'Пятница'),
(6, 'Суббота'),
(7, 'Воскресенье');

-- 
-- Вывод данных для таблицы classroom
--
-- Таблица schedule08.classroom не содержит данных

-- 
-- Вывод данных для таблицы auth_item
--
INSERT INTO auth_item VALUES
('admin', 1, 'Администратор', NULL, NULL, 1604491005, 1604491005),
('adminManager', 2, 'Администрирование ресурсов', NULL, NULL, 1604491006, 1604491006),
('manager', 1, 'Менеджер', NULL, NULL, 1604491006, 1604491006),
('student', 1, 'Студент', NULL, NULL, 1604491006, 1604491006),
('teacher', 1, 'Преподаватель', NULL, NULL, 1604491006, 1604491006);

-- 
-- Вывод данных для таблицы student
--
-- Таблица schedule08.student не содержит данных

-- 
-- Вывод данных для таблицы schedule
--
-- Таблица schedule08.schedule не содержит данных

-- 
-- Вывод данных для таблицы migration
--
INSERT INTO migration VALUES
('m000000_000000_base', 1604490707),
('m140506_102106_rbac_init', 1604490712),
('m170907_052038_rbac_add_index_on_auth_assignment_user_id', 1604490713),
('m180523_151638_rbac_updates_indexes_without_prefix', 1604490714),
('m200409_110543_rbac_update_mssql_trigger', 1604490714);

-- 
-- Вывод данных для таблицы auth_item_child
--
INSERT INTO auth_item_child VALUES
('admin', 'adminManager'),
('manager', 'adminManager');

-- 
-- Вывод данных для таблицы auth_assignment
--
INSERT INTO auth_assignment VALUES
('admin', '1', 1604491006);

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
--
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS */;